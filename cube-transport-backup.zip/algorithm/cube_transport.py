"""スタート地点でPower Cubeを拾い、ゴール地点に置いて戻る。"""

from math import atan2, degrees, dist, hypot
from time import monotonic

from pycozmo.robot import MIN_LIFT_HEIGHT

from algorithm.mapped_driving import CARRY_INSET_MM, TURN_TOLERANCE_DEG, MappedMotion
from algorithm.mapping.drive_limits import position_ahead, rotate_point
from algorithm.table_roaming import angle_difference, drive_in_background
from camera.cube_detection import CARRY_VIEW_HEAD_ANGLE_RAD, CUBE_VIEW_HEAD_ANGLE_RAD


SITE_INSET_MM = 65.0
MIN_ROUTE_LENGTH_MM = 125.0
SEARCH_DISTANCE_MM = 145.0
VISUAL_DOCK_DISTANCE_MM = 98.0
# 機体原点から持ち上げ位置にあるキューブ中心までの距離。実機で調整する。
PICKUP_OFFSET_MM = 65.0
PLACEMENT_OFFSET_MM = 65.0
CARRY_LIFT_HEIGHT_MM = 55.0
BACKOFF_MM = 42.0
MAX_CUBE_OFFSET_MM = 75.0
CUBE_CLEARANCE_MM = 68.0
HEADING_OFFSETS_DEG = (0, 22.5, -22.5, 45, -45, 67.5, -67.5, 90, -90,
                       112.5, -112.5, 135, -135, 157.5, -157.5, 180)


def transport_on_map(robot, drive_map, cube_camera, *, route):
    start, goal = route

    def drive(robot, read):
        try:
            motion = MappedMotion(robot, read, drive_map)
            CubeTransport(motion, cube_camera, start, goal).run()
            drive_map.set_status("Complete - returned to Start")
            print("キューブの搬送が完了し、スタート地点に戻りました。")
        except Exception:
            drive_map.set_status("Transport stopped - see console")
            raise
        finally:
            drive_map.pause()

    return drive_in_background(robot, drive)


class CubeTransport:
    def __init__(self, motion, camera, start, goal):
        self.motion = motion
        self.camera = camera
        self.start = start
        self.goal = goal

    def run(self):
        motion = self.motion
        resume = motion.resume_after_cliff
        drop, retreat, heading = self._goal_placement()
        resume("Driving to Start", self._dock)
        motion.map.set_status("Lifting and checking the cube")
        self._set_lift(CARRY_LIFT_HEIGHT_MM)
        motion.carrying = True
        motion.robot.set_head_angle(CARRY_VIEW_HEAD_ANGLE_RAD)

        backed_off = False

        def check_pickup():
            nonlocal backed_off
            if not backed_off:
                # 段差から復帰した場合は、復帰時の後退でキューブが元の位置から離れている。
                backed_off = True
                motion.straight(-BACKOFF_MM)
            self._verify_pickup()

        resume("Checking cube pickup", check_pickup)

        def reach_goal():
            motion.go_to(drop)
            motion.turn_to(heading)
            self._verify_pickup()

        resume("Carrying cube to Goal", reach_goal)
        motion.map.set_status("Putting down the cube")
        self._set_lift(MIN_LIFT_HEIGHT.mm)
        motion.carrying = False

        def leave_goal():
            state = motion.read()
            if abs(angle_difference(heading, state.heading_deg)) < 5:
                along, cross = self._relative(state.position, heading, retreat)
                if -BACKOFF_MM - 8 <= along < -2 and abs(cross) < 10:
                    motion.straight(along)
            self._go_around_delivered_cube()

        resume("Returning to Start", leave_goal)

    def _dock(self):
        motion = self.motion
        self._set_lift(MIN_LIFT_HEIGHT.mm)
        motion.robot.set_head_angle(CUBE_VIEW_HEAD_ANGLE_RAD)
        state = motion.read()
        # キューブを置いた点の手前に止まり、そこから映像で位置を詰める。
        staging, heading = self._pickup_staging(state.position)
        motion.go_to(staging)
        motion.map.set_status("Finding cube near Start")
        for offset in (0, 22.5, -22.5):
            motion.turn_to(heading + offset)
            point = self._locate_cube(seconds=2.2)
            if point is not None:
                break
        else:
            raise RuntimeError("スタート地点の近くでPower Cubeを検知できませんでした。")

        motion.map.set_status("Aligning with the cube")
        for _ in range(9):
            state = motion.read()
            forward, left = self._relative(state.position, state.heading_deg, point)
            bearing_error = degrees(atan2(left, forward))
            if forward < 0 or abs(bearing_error) > 65:
                raise RuntimeError("キューブが正面の接近範囲から外れました。")
            if abs(bearing_error) > TURN_TOLERANCE_DEG:
                motion.turn_to(state.heading_deg + bearing_error)
            elif forward > VISUAL_DOCK_DISTANCE_MM + 6:
                motion.straight(min(25.0, forward - VISUAL_DOCK_DISTANCE_MM))
            elif forward < VISUAL_DOCK_DISTANCE_MM - 12:
                motion.straight(forward - VISUAL_DOCK_DISTANCE_MM)
            else:
                # 直前の観測を選択点に合わせ、表示と後続の走行に同じ補正を使う。
                dx, dy = self.start[0] - point[0], self.start[1] - point[1]
                result = position_ahead(state.position, state.heading_deg, forward - PICKUP_OFFSET_MM)
                dock = (result[0] + dx, result[1] + dy)
                if min(motion.table.clearances(dock)) < max(CARRY_INSET_MM, motion.inset) + 3:
                    raise RuntimeError("キューブを持ち上げる位置に十分な余裕がありません。")
                motion.correct_position(state, dx, dy)
                motion.straight(forward - PICKUP_OFFSET_MM, speed=12.0)
                return
            point = self._locate_cube(seconds=3.5)
            if point is None:
                break
        raise RuntimeError("キューブを持ち上げられる位置まで合わせられませんでした。")

    def _pickup_staging(self, position):
        motion = self.motion
        bearing = _bearing(position, self.start)
        clearance = min(105.0, dist(position, self.start))
        for offset in HEADING_OFFSETS_DEG:
            heading = bearing + offset
            staging = position_ahead(self.start, heading, -SEARCH_DISTANCE_MM)
            dock = position_ahead(self.start, heading, -PICKUP_OFFSET_MM)
            if (
                min(motion.table.clearances(staging)) >= motion.inset + 8
                and min(motion.table.clearances(dock)) >= max(CARRY_INSET_MM, motion.inset) + 8
                and _segment_distance(self.start, position, staging) >= clearance - 1
            ):
                return staging, heading
        raise RuntimeError("選んだスタート地点の手前に接近できる場所がありません。")

    def _goal_placement(self):
        motion = self.motion
        inset = max(CARRY_INSET_MM, motion.inset)
        bearing = _bearing(self.start, self.goal)
        for offset in HEADING_OFFSETS_DEG:
            heading = bearing + offset
            drop = position_ahead(self.goal, heading, -PLACEMENT_OFFSET_MM)
            retreat = position_ahead(drop, heading, -BACKOFF_MM)
            if (
                min(motion.table.clearances(drop)) >= inset + 8
                and min(motion.table.clearances(retreat)) >= SITE_INSET_MM
                and _segment_distance(self.goal, retreat, self.start) >= CUBE_CLEARANCE_MM
            ):
                return drop, retreat, heading
        raise RuntimeError("選んだゴール地点にキューブを下ろす空間を確保できません。")

    def _go_around_delivered_cube(self):
        motion = self.motion
        position = motion.read().position
        if _segment_distance(self.goal, position, self.start) < CUBE_CLEARANCE_MM:
            for offset in range(0, 360, 45):
                via = position_ahead(self.goal, offset, SEARCH_DISTANCE_MM)
                if (
                    min(motion.table.clearances(via)) >= motion.inset + 8
                    and _segment_distance(self.goal, position, via) >= CUBE_CLEARANCE_MM
                    and _segment_distance(self.goal, via, self.start) >= CUBE_CLEARANCE_MM
                ):
                    motion.go_to(via)
                    break
            else:
                raise RuntimeError("置いたキューブから距離を取って戻れる経路がありません。")
        motion.go_to(self.start)

    def _locate_cube(self, *, seconds):
        previous = None
        for frame, _ in self._fresh_frames(seconds):
            points = [self.motion.map_position(point) for point in frame.positions]
            closest = min(points, key=lambda point: dist(point, self.start), default=None)
            if closest is None or dist(closest, self.start) > MAX_CUBE_OFFSET_MM:
                previous = None
                continue
            if previous is not None and dist(closest, previous) <= 15:
                return ((closest[0] + previous[0]) / 2, (closest[1] + previous[1]) / 2)
            previous = closest
        return None

    def _verify_pickup(self):
        consecutive = 0
        for frame, state in self._fresh_frames(5.0):
            in_front = any(
                abs(forward - PICKUP_OFFSET_MM) <= 14.0 and abs(left) <= 16.0
                for forward, left in (
                    self._relative(state.position, state.heading_deg, self.motion.map_position(point))
                    for point in frame.positions
                )
            )
            consecutive = consecutive + 1 if in_front or frame.has_close_cube else 0
            if consecutive >= 2:
                return
        raise RuntimeError("持ち上げたキューブを確認できませんでした。")

    def _fresh_frames(self, seconds):
        # 停止前やヘッド移動中に撮影した画像は接近・把持判定に使わない。
        after = monotonic() + 0.22
        deadline = after + seconds
        while monotonic() < deadline:
            state = self.motion.read()
            frame = self.camera.latest()
            if frame is not None and frame.received_at >= after and frame.pose_frame == state.pose_frame:
                after = frame.received_at + 0.000001
                yield frame, state

    def _set_lift(self, height):
        motion = self.motion
        motion.read()
        motion.robot.set_lift_height(height, accel=4.0, max_speed=3.0)
        ready = monotonic() + 0.25
        deadline = ready + 3.0
        while monotonic() < deadline:
            motion.read()
            if monotonic() >= ready and abs(motion.robot.lift_position.height.mm - height) <= 3:
                return
        raise RuntimeError("リフトが指定された高さに到達しませんでした。")

    @staticmethod
    def _relative(position, heading, point):
        return rotate_point((point[0] - position[0], point[1] - position[1]), -heading)


def _bearing(start, end):
    return degrees(atan2(end[1] - start[1], end[0] - start[0]))


def _segment_distance(point, start, end):
    x, y = end[0] - start[0], end[1] - start[1]
    px, py = point[0] - start[0], point[1] - start[1]
    length_squared = x * x + y * y
    if length_squared == 0:
        return hypot(px, py)
    fraction = max(0.0, min(1.0, (px * x + py * y) / length_squared))
    return hypot(px - fraction * x, py - fraction * y)
