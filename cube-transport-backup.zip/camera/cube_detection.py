"""Power Cubeの検知枠を、画像受信時の機体座標から走行座標へ投影する。"""

from dataclasses import dataclass
from math import atan2, cos, isfinite, radians, sin
from threading import Lock

from algorithm.mapping.drive_limits import rotate_point


CUBE_SIZE_MM = 44.0
CUBE_VIEW_HEAD_ANGLE_RAD = radians(-6)
CARRY_VIEW_HEAD_ANGLE_RAD = radians(16)

# QVGAでの焦点距離と光学中心。機体の校正値を取得できる場合はそちらを使う。
DEFAULT_INTRINSICS = (288.0, 288.0, 160.0, 120.0)
# 機体原点からヘッド軸、ヘッド軸からカメラへの前方・上方オフセット。
NECK_FORWARD_MM = -13.0
CAMERA_FORWARD_MM = 17.52
CAMERA_UP_MM = -8.0
CAMERA_TILT_RAD = radians(-4)


@dataclass(frozen=True)
class CameraPose:
    position: tuple[float, float]
    heading_deg: float
    head_angle_rad: float
    pose_frame: tuple[int, int]


@dataclass(frozen=True)
class CubeFrame:
    received_at: float
    pose_frame: tuple[int, int]
    positions: tuple[tuple[float, float], ...]
    has_close_cube: bool


class CubeCamera:
    """最新の推論結果を走行スレッドへ渡す。"""

    def __init__(self):
        self._lock = Lock()
        self._frame = None

    def clear(self):
        with self._lock:
            self._frame = None

    def latest(self):
        with self._lock:
            return self._frame

    def publish(self, received_at, pose, boxes, image_size, intrinsics):
        if pose is None:
            return
        positions = []
        has_close_cube = False
        width, height = image_size
        for box in boxes:
            offset = _cube_offset(box, image_size, intrinsics, pose.head_angle_rad)
            if offset is not None:
                x, y = rotate_point(offset, pose.heading_deg)
                positions.append((pose.position[0] + x, pose.position[1] + y))
            else:
                # 持ち上げたキューブは近距離で上下左右が見切れることがある。
                x1, y1, x2, y2 = box
                has_close_cube |= (
                    x1 < 0.2 * width and x2 > 0.8 * width
                    and y2 - y1 > 0.7 * height
                )

        with self._lock:
            self._frame = CubeFrame(received_at, pose.pose_frame, tuple(positions), has_close_cube)


def capture_camera_pose(robot):
    pose = robot.pose
    x, y = pose.position.x, pose.position.y
    heading = pose.rotation.angle_z.degrees
    head_angle = robot.head_angle.radians
    if not pose.is_valid or not all(isfinite(value) for value in (x, y, heading, head_angle)):
        return None
    return CameraPose((x, y), heading, head_angle, (pose.origin_id, robot.pose_frame_id))


def camera_intrinsics(robot):
    config = getattr(robot, "camera_config", None)
    if config is None:
        return DEFAULT_INTRINSICS
    values = (config.focal_length.x, config.focal_length.y, config.center.x, config.center.y)
    if all(isfinite(value) and value > 0 for value in values):
        return values
    return DEFAULT_INTRINSICS


def _cube_offset(box, image_size, intrinsics, head_angle):
    width, height = image_size
    x_scale, y_scale = width / 320, height / 240
    fx, fy, cx, cy = intrinsics
    fx, fy, cx, cy = fx * x_scale, fy * y_scale, cx * x_scale, cy * y_scale
    x1, y1, x2, y2 = box
    if not all(isfinite(value) for value in box) or x2 - x1 < 1 or y2 - y1 < 1:
        return None

    pitch = head_angle + CAMERA_TILT_RAD
    cos_pitch, sin_pitch = cos(pitch), sin(pitch)
    # 正面の高さを優先する。幅はキューブが斜めを向くと大きく見える。
    full_width = x1 > 2 * x_scale and x2 < width - 2 * x_scale
    full_height = y1 > 2 * y_scale and y2 < height - 2 * y_scale
    middle_y = ((y1 + y2) / 2 - cy) / fy
    if full_height:
        depth = fy * CUBE_SIZE_MM * (cos_pitch + middle_y * sin_pitch) / (y2 - y1)
    elif full_width:
        depth = fx * CUBE_SIZE_MM / (x2 - x1)
    else:
        return None
    if depth <= 0:
        return None

    # 左右が見切れている場合は既知の幅から正面の中心を補う。
    center_x = (x1 + x2) / 2
    half_width = fx * CUBE_SIZE_MM / (2 * depth)
    if x1 <= 2 * x_scale and x2 < width - 2 * x_scale:
        center_x = x2 - half_width
    elif x2 >= width - 2 * x_scale and x1 > 2 * x_scale:
        center_x = x1 + half_width

    camera_forward = NECK_FORWARD_MM + CAMERA_FORWARD_MM * cos(head_angle) - CAMERA_UP_MM * sin(head_angle)
    # 光軸に沿った距離を机と平行な距離へ変換する。
    if not full_height:
        # 高さに見切れがあるときは光軸付近に正面があると近似する。
        middle_y = 0.0
    face_forward = depth * (cos_pitch + middle_y * sin_pitch)
    left = (cx - center_x) * depth / fx
    # 検知枠で推定する正面から、キューブ中心に半辺分を加える。
    bearing = atan2(left, face_forward)
    return (
        camera_forward + face_forward + CUBE_SIZE_MM / 2 * cos(bearing),
        left + CUBE_SIZE_MM / 2 * sin(bearing),
    )
