import unittest
from math import degrees, dist
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

import cv2

from algorithm.cube_transport import CubeTransport, PICKUP_OFFSET_MM
from algorithm.mapped_driving import MappedMotion
from algorithm.mapping.drive_limits import TableArea, position_ahead, rotate_point
from algorithm.mapping.drive_map import DriveMap
from algorithm.mapping.map_view import MapProjection, MapWindow
from camera.cube_detection import CubeFrame
from hardware.step_detection import StepReading


class SimulatedCozmo:
    def __init__(self, drive_map):
        self.map = drive_map
        self.position = drive_map.start_position
        self.heading = drive_map.start_heading
        self.error = (0.0, 0.0)
        self.wheels = (0.0, 0.0)
        self.time = 0.0
        self.cube = None
        self.has_cube = False
        self.lift_position = SimpleNamespace(height=SimpleNamespace(mm=32.0))

    def clock(self):
        return self.time

    def read(self):
        period = 0.05
        self.time += period
        left, right = self.wheels
        self.heading += degrees((right - left) * period / 45.0)
        self.position = position_ahead(self.position, self.heading, (left + right) * period / 2)
        sensor = self.map.sensor_position(self.position, self.heading)
        cliff = min(self.map.table.clearances(sensor)) <= 0
        return StepReading(cliff, False, self.odometry(self.position), self.heading, (1, 1), self.time)

    def odometry(self, point):
        return (point[0] + self.error[0], point[1] + self.error[1])

    def drive_wheels(self, left, right):
        self.wheels = left, right

    def stop_all_motors(self):
        self.drive_wheels(0, 0)

    def set_head_angle(self, angle):
        pass

    def set_lift_height(self, height, **kwargs):
        front = position_ahead(self.position, self.heading, PICKUP_OFFSET_MM)
        if self.has_cube and height < 40:
            self.cube = front
        self.has_cube = height > 40 and self.cube is not None and dist(front, self.cube) <= 9.0
        self.lift_position.height.mm = height

    def latest(self):
        point = position_ahead(self.position, self.heading, PICKUP_OFFSET_MM) if self.has_cube else self.cube
        return CubeFrame(self.time, (1, 1), (self.odometry(point),), False)


class TransportTests(unittest.TestCase):
    def setUp(self):
        path = next((Path(__file__).resolve().parents[1] / "data" / "roaming_maps").glob("*.json"))
        self.map = DriveMap(path)
        self.map.table = TableArea(0.0, 650.0, 0.0, 460.0, 0.0)
        self.map.start_position = (295.0, 225.0)
        self.map.start_heading = 0.0
        self.robot = SimulatedCozmo(self.map)
        for module in ("algorithm.mapped_driving", "algorithm.table_roaming", "algorithm.cube_transport"):
            timer = patch(f"{module}.monotonic", self.robot.clock)
            timer.start()
            self.addCleanup(timer.stop)
        self.motion = MappedMotion(self.robot, self.robot.read, self.map)

    def test_pickup_corrects_map_pose_drops_at_goal_and_returns(self):
        start, goal = (477.0, 223.0), (430.0, 355.0)
        offset = (12.0, -7.0)
        self.robot.cube = (start[0] + offset[0], start[1] + offset[1])

        CubeTransport(self.motion, self.robot, start, goal).run()

        _, _, pose, _, breaks, _ = self.map.drawing_snapshot()
        self.assertLess(dist(pose[:2], start), 6)
        self.assertLess(dist(self.robot.cube, (goal[0] + offset[0], goal[1] + offset[1])), 10)
        self.assertFalse(self.robot.has_cube)
        self.assertTrue(breaks)

    def test_recovers_two_axes_and_resumes_travel_with_cube(self):
        self.motion.carrying = True
        self.robot.error = (-80.0, 35.0)
        target = (555.0, 255.0)

        self.motion.resume_after_cliff("Carrying", lambda: self.motion.go_to(target))

        _, edges, pose, _, breaks, status = self.map.drawing_snapshot()
        self.assertLess(dist(self.robot.position, target), 6)
        self.assertLess(dist(pose[:2], self.robot.position), 2)
        self.assertEqual(status, "Carrying")
        self.assertGreaterEqual(len(breaks), 2)
        self.assertTrue(any(abs(point[0] - 650.0) < 2 for point in edges))
        self.assertTrue(any(abs(point[1] - 460.0) < 2 for point in edges))

    def test_map_click_reverses_projection_with_pixel_rounding(self):
        projection = MapProjection.fit([(-200.0, -100.0), (410.0, 280.0)])
        point = (203.0, 38.0)
        pixel = projection.to_pixel(point)
        self.assertLess(dist(projection.to_position(*pixel), point), 1.5)

    def test_map_uses_table_points_and_requires_both_clicks_before_start(self):
        drive_map = DriveMap(self.map.path)
        corner, _ = drive_map.table_bounds().segments_mm[0]
        table = drive_map.table
        start = rotate_point((table.u_min + 105, table.v_min + 105), table.angle_deg)
        goal = rotate_point((table.u_max - 105, table.v_max - 105), table.angle_deg)
        with (
            patch.object(cv2, "namedWindow"), patch.object(cv2, "setMouseCallback"),
            patch.object(cv2, "moveWindow"), patch.object(cv2, "imshow") as show,
        ):
            window = MapWindow(drive_map, "Camera", 640, route_limits=(65, 125))
            self.assertEqual(show.call_args.args[1].shape, (480, 420, 3))
            for point in (corner, start):
                window._on_mouse(cv2.EVENT_LBUTTONUP, *window.projection.to_pixel(point), 0, None)
                self.assertIsNone(window.confirm_route())
            window._on_mouse(cv2.EVENT_LBUTTONUP, *window.projection.to_pixel(goal), 0, None)
            actual_start, actual_goal = window.confirm_route()
            self.assertLess(dist(start, actual_start), 1.5)
            self.assertLess(dist(goal, actual_goal), 1.5)
            self.assertIsNone(window.confirm_route())


if __name__ == "__main__":
    unittest.main()
